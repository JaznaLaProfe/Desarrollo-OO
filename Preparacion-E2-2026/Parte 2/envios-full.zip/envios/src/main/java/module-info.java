module ayudantia.ejercicio.envios {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.google.gson;

    opens ayudantia.ejercicio.envios to javafx.fxml;
    exports ayudantia.ejercicio.envios;

    opens ayudantia.ejercicio.envios.controller to javafx.fxml;
    exports  ayudantia.ejercicio.envios.controller;

    opens ayudantia.ejercicio.envios.model to javafx.base, com.google.gson;
    opens  ayudantia.ejercicio.envios.dao to javafx.base;
}