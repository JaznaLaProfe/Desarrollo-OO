package ayudantia.ejercicio.envios.controller;

import ayudantia.ejercicio.envios.model.Envio;
import ayudantia.ejercicio.envios.model.EnvioEstandar;
import ayudantia.ejercicio.envios.model.EnvioExpress;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.IOException;

public class EnvioController {

    @FXML
    private Button btnLimpiar;

    @FXML
    private Button btnRegistrar;

    @FXML
    private CheckBox checkUrgente;

    @FXML
    private TableColumn<?, ?> columnCodigo;

    @FXML
    private TableColumn<Envio, String> columnCosto;

    @FXML
    private TableColumn<?, ?> columnDistancia;

    @FXML
    private TableColumn<?, ?> columnPeso;

    @FXML
    private TableColumn<Envio, String> columnTipo;

    @FXML
    private TableColumn<Envio, String> columnVariable;

    @FXML
    private ComboBox<String> comboTipo;

    @FXML
    private Label lblTarifa;

    @FXML
    private Label lblUrgente;

    @FXML
    private TableView<Envio> tableViewEnvios;

    @FXML
    private TextField txtCodigo;

    @FXML
    private TextField txtDistancia;

    @FXML
    private TextField txtPeso;

    @FXML
    private TextField txtTarifa;

    private ObservableList<Envio> coleccion;

    @FXML
    public void initialize() throws IOException {
        this.coleccion = FXCollections.observableArrayList(new EnvioEstandar().listar());
        this.comboTipo.getItems().addAll("Estándar", "Express");
        this.comboTipo.getSelectionModel().selectFirst();

        this.lblUrgente.setVisible(false);
        this.checkUrgente.setVisible(false);

        /* Inicializar las columnas del Table View */
        this.columnCodigo.setCellValueFactory(new PropertyValueFactory<>("codigo"));
        this.columnDistancia.setCellValueFactory(new PropertyValueFactory<>("distancia"));
        this.columnPeso.setCellValueFactory(new PropertyValueFactory<>("peso"));

        /* Inicializa la columna de tipo */
        this.columnTipo.setCellValueFactory(cellData ->{
            Envio e = cellData.getValue();
            String tipo = (e instanceof EnvioEstandar? "ESTANDAR": "EXPRESS");
            return new SimpleStringProperty(tipo);
        });

        this.columnVariable.setCellValueFactory(cellData ->{
            Envio e = cellData.getValue();
            if (e instanceof EnvioEstandar estandar){
                int tarifa = estandar.getTarifaBase();
                return new SimpleStringProperty(String.valueOf(tarifa));
            }
            else{
                EnvioExpress express = ((EnvioExpress) e);
                String esUrgente = (express.getEsUrgente()?"SI":"NO");
                return new SimpleStringProperty(esUrgente);
            }
        });

        this.columnCosto.setCellValueFactory(cellData ->{
            Envio e = cellData.getValue();
            double costo = e.calcularCosto();
            return new SimpleStringProperty(String.valueOf(costo));
        });

        this.tableViewEnvios.setItems(this.coleccion);
        this.txtCodigo.requestFocus();
    }
    @FXML
    void handleLimpiar(ActionEvent event) {
        this.txtCodigo.setText("");
        this.txtTarifa.setText("");
        this.checkUrgente.setSelected(false);
        this.comboTipo.getSelectionModel().selectFirst();
        this.txtDistancia.setText("");
        this.txtPeso.setText("");

        this.txtCodigo.requestFocus();
    }

    @FXML
    void handleRegistrar(ActionEvent event) {
        /* Crear el objeto */
        try {
            Envio nuevo = crearEnvio();
            this.coleccion.add(nuevo);
            nuevo.grabar();
            mostrarAlerta(Alert.AlertType.INFORMATION, "Gestión envíos",
                    "Envio registrado exitosamente");
            this.handleLimpiar(event);
        }
        catch(Exception e){
            mostrarAlerta(Alert.AlertType.ERROR, "Gestión envíos", e.getMessage());
        }
    }

    private void mostrarAlerta(Alert.AlertType tipo, String titulo, String mensaje){
        Alert alerta = new Alert(tipo);
        alerta.setTitle(titulo);
        alerta.setContentText(mensaje);
        alerta.setHeaderText(null);
        alerta.showAndWait();

    }
    private Envio crearEnvio(){
        /* Rescatar los datos desde la UI */
        String codigo = this.txtCodigo.getText();
        double peso = Double.parseDouble(this.txtPeso.getText());
        double distancia = Double.parseDouble(this.txtDistancia.getText());

        /* Diferencia entre el tipo de envio */
        if (this.comboTipo.getValue().equalsIgnoreCase("estándar")){
            int tarifa = Integer.parseInt(this.txtTarifa.getText());
            return new EnvioEstandar(codigo,peso,distancia, tarifa);
        }
        else{
            boolean esUrgente = this.checkUrgente.isSelected();
            return new EnvioExpress(codigo, peso, distancia, esUrgente);
        }
    }

    @FXML
    void handleTipo(ActionEvent event) {
        boolean esEstandar = this.comboTipo.getValue().equalsIgnoreCase("estándar");

        this.lblTarifa.setVisible(esEstandar);
        this.txtTarifa.setVisible(esEstandar);

        this.lblUrgente.setVisible(!esEstandar);
        this.checkUrgente.setVisible(!esEstandar);
    }

}
