package ayudantia.ejercicio.envios;

import javafx.application.Application;

public class Launcher {
    public static void main(String[] args) {
        Application.launch(EnvoApplication.class, args);
    }
}
