package ayudantia.ejercicio.envios.model;

public interface ICalculable {
    double calcularCosto();
}
