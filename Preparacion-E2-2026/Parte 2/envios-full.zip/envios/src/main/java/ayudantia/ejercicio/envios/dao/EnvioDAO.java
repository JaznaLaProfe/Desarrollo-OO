package ayudantia.ejercicio.envios.dao;

import ayudantia.ejercicio.envios.model.Envio;
import ayudantia.ejercicio.envios.model.EnvioEstandar;
import ayudantia.ejercicio.envios.model.EnvioExpress;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class EnvioDAO {
    private final Gson gson;
    private final Path archivoEstandar;
    private final Path archivoExpress;

    private static final Type TIPO_ESTANDAR = new TypeToken<List<EnvioEstandar>>() {}.getType();

    private static final Type TIPO_EXPRESS = new TypeToken<List<EnvioExpress>>() {}.getType();

    public EnvioDAO() {
        gson = new GsonBuilder().setPrettyPrinting().create();
        Path carpeta = Path.of("data");
        archivoEstandar = carpeta.resolve("estandar.json");
        archivoExpress = carpeta.resolve("express.json");
    }

    public List<Envio> cargarTodos() throws IOException {
        List<Envio> envios = new ArrayList<>();
        envios.addAll(cargarEstandar());
        envios.addAll(cargarExpress());
        return envios;
    }

    private List<EnvioEstandar> cargarEstandar() throws IOException {
        if (!Files.exists(archivoEstandar)) {
            return new ArrayList<>();
        }
        String json = Files.readString(archivoEstandar);
        List<EnvioEstandar> lista = gson.fromJson(json, TIPO_ESTANDAR);
        return lista == null ? new ArrayList<>() : lista;
    }

    private List<EnvioExpress> cargarExpress() throws IOException {
        if (!Files.exists(archivoExpress)) {
            return new ArrayList<>();
        }
        String json = Files.readString(archivoExpress);
        List<EnvioExpress> lista = gson.fromJson(json, TIPO_EXPRESS);
        return lista == null ? new ArrayList<>() : lista;
    }

    public void guardarTodos(List<Envio> envios) throws IOException {
        Files.createDirectories(archivoEstandar.getParent());

        List<EnvioEstandar> lst_estandar = new ArrayList<>();
        List<EnvioExpress> lst_express = new ArrayList<>();

        for (Envio e : envios) {
            if (e instanceof EnvioEstandar un_estandar) {
                lst_estandar.add(un_estandar);
            } else if (e instanceof EnvioExpress un_express) {
                lst_express.add(un_express);
            }
        }

        Files.writeString(archivoEstandar, gson.toJson(lst_estandar));
        Files.writeString(archivoExpress, gson.toJson(lst_express));
    }

    public void crear(Envio nuevoEnvio) throws IOException {
        // Asegura que la carpeta 'data' exista antes de operar
        Files.createDirectories(archivoEstandar.getParent());

        // Identifica el tipo de objeto usando instanceof (Pattern Matching)
        if (nuevoEnvio instanceof EnvioEstandar nuevoEstandar) {
            // 1. Carga los envíos estándar que ya existen en el archivo
            List<EnvioEstandar> estandarExistentes = cargarEstandar();

            // 2. Agrega el nuevo envio a la lista en memoria
            estandarExistentes.add(nuevoEstandar);

            // 3. Sobrescribe el archivo con la lista actualizada
            Files.writeString(archivoEstandar, gson.toJson(estandarExistentes));

        } else if (nuevoEnvio instanceof EnvioExpress nuevoExpress) {
            // 1. Carga los envios express que ya existen en el archivo
            List<EnvioExpress> expressExistentes = cargarExpress();

            // 2. Agrega el nuevo envio express a la lista en memoria
            expressExistentes.add(nuevoExpress);

            // 3. Sobrescribe el archivo con la lista actualizada
            Files.writeString(archivoExpress, gson.toJson(expressExistentes));
        }
    }

}
