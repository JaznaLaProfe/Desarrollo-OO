package ayudantia.ejercicio.envios.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class EnvioController {

    @FXML
    private Button btnLimpiar;

    @FXML
    private Button btnRegistrar;

    @FXML
    private CheckBox checkUrgente;

    @FXML
    private TableColumn<?, ?> columnCodigo;

    @FXML
    private TableColumn<?, ?> columnCosto;

    @FXML
    private TableColumn<?, ?> columnDistancia;

    @FXML
    private TableColumn<?, ?> columnPeso;

    @FXML
    private TableColumn<?, ?> columnTipo;

    @FXML
    private TableColumn<?, ?> columnVariable;

    @FXML
    private ComboBox<?> comboTipo;

    @FXML
    private Label lblTarifa;

    @FXML
    private Label lblUrgente;

    @FXML
    private TableView<?> tableViewEnvios;

    @FXML
    private TextField txtCodigo;

    @FXML
    private TextField txtDistancia;

    @FXML
    private TextField txtPeso;

    @FXML
    private TextField txtTarifa;

    @FXML
    void handleLimpiar(ActionEvent event) {

    }

    @FXML
    void handleRegistrar(ActionEvent event) {

    }

    @FXML
    void handleTipo(ActionEvent event) {

    }

}
