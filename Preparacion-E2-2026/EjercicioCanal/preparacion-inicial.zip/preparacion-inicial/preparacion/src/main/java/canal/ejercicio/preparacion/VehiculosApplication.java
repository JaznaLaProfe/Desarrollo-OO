package canal.ejercicio.preparacion;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class VehiculosApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(VehiculosApplication.class.getResource("main-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 620, 600);
        stage.setTitle("Ejercicio de preparación");
        stage.setResizable(false);
        stage.setScene(scene);
        stage.show();
    }
}
