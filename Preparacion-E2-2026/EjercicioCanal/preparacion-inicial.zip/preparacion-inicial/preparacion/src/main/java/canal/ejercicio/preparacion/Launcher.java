package canal.ejercicio.preparacion;

import javafx.application.Application;

public class Launcher {
    public static void main(String[] args) {
        Application.launch(VehiculosApplication.class, args);
    }
}
