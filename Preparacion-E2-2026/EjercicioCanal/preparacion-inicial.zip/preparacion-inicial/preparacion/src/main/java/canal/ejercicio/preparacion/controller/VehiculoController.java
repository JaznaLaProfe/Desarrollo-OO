package canal.ejercicio.preparacion.controller;

import canal.ejercicio.preparacion.model.Automovil;
import canal.ejercicio.preparacion.model.Camioneta;
import canal.ejercicio.preparacion.model.Vehiculo;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableArray;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.IOException;

public class VehiculoController {

    @FXML
    private Button btnLimpiar;

    @FXML
    private Button btnRegistrar;

    @FXML
    private CheckBox checkSeguro;

    @FXML
    private TableColumn<?, ?> columnDias;

    @FXML
    private TableColumn<?, ?> columnPatente;

    @FXML
    private TableColumn<Vehiculo, String> columnPrecioBase;

    @FXML
    private TableColumn<Vehiculo, String> columnTipo;

    @FXML
    private TableColumn<Vehiculo, String> columnValorArriendo;

    @FXML
    private TableColumn<Vehiculo, String> columnVariable;

    @FXML
    private ComboBox<String> comboTipo;

    @FXML
    private Label lblCarga;

    @FXML
    private Label lblSeguro;

    @FXML
    private TableView<Vehiculo> tableVehiculos;

    @FXML
    private TextField txtCarga;

    @FXML
    private TextField txtDias;

    @FXML
    private TextField txtPatente;

    @FXML
    private TextField txtPrecio;

    private ObservableList<Vehiculo> coleccion;

    @FXML
    void handleLimpiar(ActionEvent event) {
        this.txtPatente.setText("");
        this.txtPrecio.setText("");
        this.txtCarga.setText("");
        this.txtDias.setText("");
        this.checkSeguro.setSelected(false);

        this.comboTipo.getSelectionModel().selectFirst();
    }

    @FXML
    public void initialize() throws IOException {

        this.comboTipo.getItems().addAll("Automovil", "Camioneta");
        this.comboTipo.getSelectionModel().selectFirst();

        this.lblCarga.setVisible(false);
        this.txtCarga.setVisible(false);

        this.coleccion = FXCollections.observableArrayList(new Automovil().listar());

        /* Asignar las columnas */
        this.columnPatente.setCellValueFactory(new PropertyValueFactory<>("patente"));
        this.columnPrecioBase.setCellValueFactory(new PropertyValueFactory<>("precioBaseArriendo"));
        this.columnDias.setCellValueFactory(new PropertyValueFactory<>("diasArriendo"));

        this.columnTipo.setCellValueFactory(cellData ->{
            Vehiculo v = cellData.getValue();
            String tipo = (v instanceof Automovil?"AUTO":"CAMIONETA");
            return new SimpleStringProperty(tipo);
        });

        this.columnValorArriendo.setCellValueFactory(cellData ->{
            Vehiculo v = cellData.getValue();
            double valor = v.calcularValorArriendo();
            return new SimpleStringProperty(String.valueOf(valor));
        });

        this.columnVariable.setCellValueFactory(cellData ->{
            Vehiculo v = cellData.getValue();
            if( v instanceof Automovil auto){
                boolean tieneSeguro = auto.getTieneSeguro();
                return new SimpleStringProperty(tieneSeguro?"SI":"NO");
            }
            else{
                Camioneta c = (Camioneta) v;
                double carga = c.getCarga();
                return new SimpleStringProperty(String.valueOf(carga));
            }
        });

        this.tableVehiculos.setItems(this.coleccion);
        this.txtPatente.requestFocus();
    }

    @FXML
    void handleRegistrar(ActionEvent event) {
        try{
            Vehiculo nuevo = crearVehiculo();
            this.coleccion.add(nuevo);
            nuevo.crear();
            mostrarAlerta(Alert.AlertType.INFORMATION, "Gestión vehículos", "Vehiculo registrado correctamente");
            this.handleLimpiar(event);
        }
        catch(Exception e){
            mostrarAlerta(Alert.AlertType.ERROR, "Gestión de vehículos", e.getMessage());
        }

    }

    private Vehiculo crearVehiculo(){
        /* Obtiene los datos desde la UI */
        String patente = this.txtPatente.getText();
        int dias = Integer.parseInt(this.txtDias.getText());
        double precio = Double.parseDouble(this.txtPrecio.getText());
        if (this.comboTipo.getValue().equalsIgnoreCase("automovil")){
            boolean tieneSeguro = this.checkSeguro.isSelected();
            return new Automovil(patente, dias, precio, tieneSeguro);
        }
        else{
            double carga = Double.parseDouble(this.txtCarga.getText());
            return new Camioneta(patente, dias, precio, carga);
        }
    }

    private void mostrarAlerta(Alert.AlertType tipo, String titulo, String mensaje){
        Alert alerta = new Alert(tipo);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    @FXML
    void handleTipo(ActionEvent event) {
        /* Determina el tipo de vehiculo */
        boolean esAuto = this.comboTipo.getValue().equalsIgnoreCase("automovil");

        this.lblSeguro.setVisible(esAuto);
        this.checkSeguro.setVisible(esAuto);

        this.lblCarga.setVisible(!esAuto);
        this.txtCarga.setVisible(!esAuto);
    }

}
