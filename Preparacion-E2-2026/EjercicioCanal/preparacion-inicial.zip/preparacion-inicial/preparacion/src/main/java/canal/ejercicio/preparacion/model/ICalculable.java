package canal.ejercicio.preparacion.model;

public interface ICalculable {
    double calcularValorArriendo();
}
