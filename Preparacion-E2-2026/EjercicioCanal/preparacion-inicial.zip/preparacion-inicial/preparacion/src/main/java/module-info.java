module canal.ejercicio.preparacion {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.google.gson;


    opens canal.ejercicio.preparacion to javafx.fxml;
    exports canal.ejercicio.preparacion;

    opens canal.ejercicio.preparacion.controller to javafx.fxml;
    exports canal.ejercicio.preparacion.controller;

    opens canal.ejercicio.preparacion.model to javafx.base, com.google.gson;
    opens canal.ejercicio.preparacion.dao to javafx.base;
}