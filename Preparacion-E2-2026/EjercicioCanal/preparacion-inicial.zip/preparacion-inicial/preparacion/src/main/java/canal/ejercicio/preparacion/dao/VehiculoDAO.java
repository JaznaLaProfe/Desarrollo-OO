package canal.ejercicio.preparacion.dao;

import canal.ejercicio.preparacion.model.Automovil;
import canal.ejercicio.preparacion.model.Camioneta;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import canal.ejercicio.preparacion.model.Vehiculo;

import java.io.IOException;
import java.lang.reflect.Type;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class VehiculoDAO {
    private final Gson gson;
    private final Path archivoAutos;
    private final Path archivoCamionetas;

    private static final Type TIPO_AUTO = new TypeToken<List<Automovil>>() {}.getType();

    private static final Type TIPO_CAMIONETA = new TypeToken<List<Camioneta>>() {}.getType();

    public VehiculoDAO() {
        gson = new GsonBuilder().setPrettyPrinting().create();
        Path carpeta = Path.of("data");
        archivoAutos = carpeta.resolve("autos.json");
        archivoCamionetas = carpeta.resolve("camionetas.json");
    }

    public List<Vehiculo> cargarTodos() throws IOException {
        List<Vehiculo> vehiculos = new ArrayList<>();
        vehiculos.addAll(cargarAutos());
        vehiculos.addAll(cargarCamionetas());
        return vehiculos;
    }

    private List<Automovil> cargarAutos() throws IOException {
        if (!Files.exists(archivoAutos)) {
            return new ArrayList<>();
        }
        String json = Files.readString(archivoAutos);
        List<Automovil> lista = gson.fromJson(json, TIPO_AUTO);
        return lista == null ? new ArrayList<>() : lista;
    }

    private List<Camioneta> cargarCamionetas() throws IOException {
        if (!Files.exists(archivoCamionetas)) {
            return new ArrayList<>();
        }
        String json = Files.readString(archivoCamionetas);
        List<Camioneta> lista = gson.fromJson(json, TIPO_CAMIONETA);
        return lista == null ? new ArrayList<>() : lista;
    }

    public void guardarTodos(List<Vehiculo> vehiculos) throws IOException {
        Files.createDirectories(archivoAutos.getParent());

        List<Automovil> autos = new ArrayList<>();
        List<Camioneta> camionetas = new ArrayList<>();

        for (Vehiculo v : vehiculos) {
            if (v instanceof Automovil auto) {
                autos.add(auto);
            } else if (v instanceof Camioneta camioneta) {
                camionetas.add(camioneta);
            }
        }

        Files.writeString(archivoAutos, gson.toJson(autos));
        Files.writeString(archivoCamionetas, gson.toJson(camionetas));
    }

    public void crear(Vehiculo nuevoVehiculo) throws IOException {
        // Asegura que la carpeta 'data' exista antes de operar
        Files.createDirectories(archivoAutos.getParent());

        // Identifica el tipo de objeto usando instanceof (Pattern Matching)
        if (nuevoVehiculo instanceof Automovil nuevoAuto) {
            // 1. Carga los autos que ya existen en el archivo
            List<Automovil> autosExistentes = cargarAutos();

            // 2. Agrega el nuevo automóvil a la lista en memoria
            autosExistentes.add(nuevoAuto);

            // 3. Sobrescribe el archivo con la lista actualizada
            Files.writeString(archivoAutos, gson.toJson(autosExistentes));

        } else if (nuevoVehiculo instanceof Camioneta nuevaCamioneta) {
            // 1. Carga las camionetas que ya existen en el archivo
            List<Camioneta> camionetasExistentes = cargarCamionetas();

            // 2. Agrega la nueva camioneta a la lista en memoria
            camionetasExistentes.add(nuevaCamioneta);

            // 3. Sobrescribe el archivo con la lista actualizada
            Files.writeString(archivoCamionetas, gson.toJson(camionetasExistentes));
        }
    }

}
