package canal.ejercicio.preparacion.model;

import canal.ejercicio.preparacion.dao.VehiculoDAO;

import java.io.IOException;
import java.util.List;

public abstract class Vehiculo implements ICalculable{
    /* Definicion de los atributos */
    private String patente;
    private int diasArriendo;
    private double precioBaseArriendo;

    public Vehiculo(){}
    /* Constructor */
    public Vehiculo(String patente, int diasArriendo, double precioBaseArriendo){
        this.setPatente(patente);
        this.setDiasArriendo(diasArriendo);
        this.setPrecioBaseArriendo(precioBaseArriendo);
    }
    /* Métodos GETTER */
    public String getPatente(){
        return this.patente;
    }

    public int getDiasArriendo(){ return this.diasArriendo;}

    public double getPrecioBaseArriendo(){ return this.precioBaseArriendo;}

    /* Métodos SETTER */
    public void setPatente(String patente){
        if (patente != null && patente.length() == 6){
            this.patente = patente;
        }
        else {
            throw new IllegalArgumentException("Patente no cumple con requisito");
        }
    }

    public void setDiasArriendo(int diasArriendo){
        if (diasArriendo <= 0){
            throw new IllegalArgumentException("Dìas de arriendo no cumple con requisito");
        }
        this.diasArriendo = diasArriendo;
    }

    public void setPrecioBaseArriendo(double precioBaseArriendo){
        if (precioBaseArriendo <= 15000){
            throw new IllegalArgumentException("Precio base no cumple con requisito");
        }
        this.precioBaseArriendo = precioBaseArriendo;
    }

    public String toString(){
        return "Matricula " + this.patente + " Dias arriendo " + this.diasArriendo +
                " Precio base arriendo " + this.precioBaseArriendo;
    }

    public List<Vehiculo> listar() throws IOException {
        VehiculoDAO dao = new VehiculoDAO();
        return dao.cargarTodos();
    }

    public void crear() throws IOException {
        VehiculoDAO dao = new VehiculoDAO();
        dao.crear(this);
    }
}
