package canal.ejercicio.preparacion.controller;

import canal.ejercicio.preparacion.model.Automovil;
import canal.ejercicio.preparacion.model.Camioneta;
import canal.ejercicio.preparacion.model.Vehiculo;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.IOException;

public class VehiculoController {

    @FXML
    private Button btnLimpiar;

    @FXML
    private Button btnRegistrar;

    @FXML
    private CheckBox checkSeguro;

    @FXML
    private ComboBox<String> comboTipo;

    @FXML
    private TableView<Vehiculo> tableVehiculos;
    @FXML
    private TableColumn<Vehiculo, Integer> columnDias;

    @FXML
    private TableColumn<Vehiculo, String> columnPatente;

    @FXML
    private TableColumn<Vehiculo, Double> columnPrecioBase;

    @FXML
    private TableColumn<Vehiculo, String> columnValorArriendo;

    @FXML
    private TableColumn<Vehiculo, String> columnTipo;

    @FXML
    private TableColumn<Vehiculo, String> columnVariable;

    @FXML
    private TextField txtDias;

    @FXML
    private TextField txtPatente;

    @FXML
    private TextField txtPrecio;

    @FXML
    private Label lblSeguro;

    @FXML
    private Label lblCarga;
    @FXML
    private TextField txtCarga;
    private ObservableList<Vehiculo> coleccion;

    public void initialize() throws IOException {
        this.coleccion = FXCollections.observableArrayList(new Automovil().listar());
        this.comboTipo.getItems().addAll("Automovil", "Camioneta");
        this.comboTipo.getSelectionModel().selectFirst();

        this.lblCarga.setVisible(false);
        this.txtCarga.setVisible(false);

        /* Asocia las columnas */
        this.columnPatente.setCellValueFactory(new PropertyValueFactory<>("patente"));
        this.columnDias.setCellValueFactory(new PropertyValueFactory<>("diasArriendo"));
        this.columnPrecioBase.setCellValueFactory(new PropertyValueFactory<>("precioBaseArriendo"));
        this.columnValorArriendo.setCellValueFactory(cellData ->{
            Vehiculo v = cellData.getValue();
            double arriendo = v.calcularValorArriendo();
            return new SimpleStringProperty(String.valueOf(arriendo));
        });

        this.columnTipo.setCellValueFactory(cellData -> {
            Vehiculo v = cellData.getValue();
            String valor = v instanceof Automovil? "Automovil":"Camioneta";
            return new SimpleStringProperty(valor);
        });

        this.columnVariable.setCellValueFactory(cellData ->{
            Vehiculo v = cellData.getValue();
            if (v instanceof Automovil){
                return new SimpleStringProperty((((Automovil) v).getTieneSeguro()?"SI":"NO"));
            }
            else{
                double carga = ((Camioneta) v).getCarga();
                return new SimpleStringProperty(String.valueOf(carga));
            }
        });

        this.tableVehiculos.setItems(this.coleccion);
        this.txtPatente.requestFocus();
    }

    @FXML
    void handleTipo(ActionEvent event) {
        boolean esAuto = this.comboTipo.getValue().equalsIgnoreCase("Automovil");
        this.lblCarga.setVisible(!esAuto);
        this.txtCarga.setVisible(!esAuto);

        this.lblSeguro.setVisible(esAuto);
        this.checkSeguro.setVisible(esAuto);

        this.txtPatente.requestFocus();
    }
    @FXML
    void handleLimpiar(ActionEvent event) {
        this.txtPatente.setText("");
        this.txtCarga.setText("");
        this.txtDias.setText("");
        this.txtCarga.setText("");
        this.txtPrecio.setText("");
        this.checkSeguro.setSelected(false);
        this.comboTipo.getSelectionModel().selectFirst();

        this.tableVehiculos.getSelectionModel().clearSelection();
        this.txtPatente.requestFocus();
    }

    @FXML
    void handleRegistrar(ActionEvent event) {
        try {
            /* Crea el objeto */
            Vehiculo v = crearVehiculo();
            v.crear();
            //if (v instanceof Automovil) ((Automovil) v).crear();
            //else ((Camioneta) v).crear();

            this.coleccion.add(v);
            this.tableVehiculos.setItems(this.coleccion);

            mostrarAlerta(Alert.AlertType.INFORMATION, "Creación vehiculo", "Vehículo agregado correctamente");
            this.handleLimpiar(event);
        }
        catch(Exception e){
            mostrarAlerta(Alert.AlertType.ERROR, "Creación vehículo",
                    e.getMessage());
        }
    }

    private Vehiculo crearVehiculo(){
        String patente = this.txtPatente.getText();
        int dias = Integer.parseInt(this.txtDias.getText());
        double precioBase = Double.parseDouble(this.txtPrecio.getText());

        if ("Automovil".equalsIgnoreCase(this.comboTipo.getValue())){
            boolean tieneSeguro = this.checkSeguro.isSelected();
            return new Automovil(patente, dias, precioBase, tieneSeguro);
        }
        else {
            double carga = Double.parseDouble(this.txtCarga.getText());
            return new Camioneta(patente, dias, precioBase, carga);
        }
    }

    /**
     * Mostrar la alerta si ha ocurrido alguna excepción
     * */
    private void mostrarAlerta(Alert.AlertType tipo, String titulo, String mensaje) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}
