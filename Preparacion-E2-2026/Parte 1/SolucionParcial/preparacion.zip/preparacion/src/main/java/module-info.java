module evaluacion.preparacion {
    requires javafx.controls;
    requires javafx.fxml;


    opens evaluacion.preparacion to javafx.fxml;
    exports evaluacion.preparacion;

    opens evaluacion.preparacion.controller to javafx.fxml;
    exports evaluacion.preparacion.controller;
}