package evaluacion.preparacion;

import javafx.application.Application;

public class Launcher {
    public static void main(String[] args) {
        Application.launch(EnvioApplication.class, args);
    }
}
