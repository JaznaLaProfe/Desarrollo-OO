/**
 * Sample Skeleton for 'main-view.fxml' Controller Class
 */

package evaluacion.preparacion.controller;

import evaluacion.preparacion.model.Envio;
import evaluacion.preparacion.model.EnvioEstandar;
import evaluacion.preparacion.model.EnvioExpress;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class EnvioController {

    @FXML // fx:id="btnActualizar"
    private Button btnActualizar; // Value injected by FXMLLoader

    @FXML // fx:id="btnCrear"
    private Button btnCrear; // Value injected by FXMLLoader

    @FXML // fx:id="btnEliminar"
    private Button btnEliminar; // Value injected by FXMLLoader

    @FXML // fx:id="btnLimpiar"
    private Button btnLimpiar; // Value injected by FXMLLoader

    @FXML // fx:id="checkUrgente"
    private CheckBox checkUrgente; // Value injected by FXMLLoader

    @FXML // fx:id="comboTipo"
    private ComboBox<String> comboTipo; // Value injected by FXMLLoader

    @FXML // fx:id="lblTarifa"
    private Label lblTarifa; // Value injected by FXMLLoader

    @FXML // fx:id="lblUrgente"
    private Label lblUrgente; // Value injected by FXMLLoader

    @FXML // fx:id="listViewEnvios"
    private ListView<Envio> listViewEnvios; // Value injected by FXMLLoader

    @FXML // fx:id="txtCodigo"
    private TextField txtCodigo; // Value injected by FXMLLoader

    @FXML // fx:id="txtPeso"
    private TextField txtPeso; // Value injected by FXMLLoader

    @FXML // fx:id="txtTarifa"
    private TextField txtTarifa; // Value injected by FXMLLoader

    @FXML // fx:id="txtDistancia"
    private TextField txtDistancia; // Value injected by FXMLLoader

    /* Colección para guardar los elementos */
    private final ObservableList<Envio> coleccion = FXCollections.observableArrayList();
    @FXML
    public void initialize(){
        this.comboTipo.getItems().addAll("Estándar", "Express");
        this.comboTipo.getSelectionModel().selectFirst();

        this.listViewEnvios.setItems(this.coleccion);

        /* Dejar invisible */
        this.lblUrgente.setVisible(false);
        this.checkUrgente.setVisible(false);

        this.txtCodigo.requestFocus();
    }
    @FXML
    private void cambioTipo(ActionEvent event) {

    }

    @FXML
    private void handleActualizar(ActionEvent event) {

    }

    private Envio crearEnvio(){
        String codigo = this.txtCodigo.getText();
        double peso = Double.parseDouble(this.txtPeso.getText());
        double distancia = Double.parseDouble(this.txtDistancia.getText());
        if ("Estándar".equalsIgnoreCase(this.comboTipo.getValue())){
            int tarifa = Integer.parseInt(this.txtTarifa.getText());
            return new EnvioEstandar(codigo, peso, distancia, tarifa);
        }
        else{
            boolean esUrgente = this.checkUrgente.isSelected();
            return new EnvioExpress(codigo, peso, distancia, esUrgente);
        }
    }
    @FXML
    private void handleCrear(ActionEvent event) {
        try {
            Envio nuevo = crearEnvio();
            this.coleccion.add(nuevo);
            this.handleLimpiar(event);
            /* Mostrar un mensaje de éxito */
            this.mostrarAlerta(Alert.AlertType.INFORMATION, "Registro e envio",
                    "Registro exitoso");
        }
        catch(Exception e){
            /* Mostrar un mensaje de error */
            this.mostrarAlerta(Alert.AlertType.ERROR, "Error al registrar", e.getMessage());
        }
    }

    private void mostrarAlerta(Alert.AlertType tipo, String titulo, String mensaje) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    @FXML
    private void handleEliminar(ActionEvent event) {

    }

    @FXML
    private void handleLimpiar(ActionEvent event) {
        this.txtCodigo.setText("");
        this.txtPeso.setText("");
        this.txtDistancia.setText("");
        this.comboTipo.getSelectionModel().selectFirst();
        this.txtTarifa.setText("");
        this.checkUrgente.setSelected(false);
        this.listViewEnvios.getSelectionModel().clearSelection();
        this.txtCodigo.requestFocus();
    }

}

