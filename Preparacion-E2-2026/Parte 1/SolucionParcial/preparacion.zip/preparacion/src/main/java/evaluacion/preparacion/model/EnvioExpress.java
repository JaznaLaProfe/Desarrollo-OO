package evaluacion.preparacion.model;

public class EnvioExpress extends Envio {
    private boolean esUrgente;

    public EnvioExpress(String codigo, double peso, double distancia, boolean esUrgente) {
        super(codigo, peso, distancia);
        this.setEsUrgente(esUrgente);
    }

    public boolean getEsUrgente() { return this.esUrgente; }

    public void setEsUrgente(boolean esUrgente) {
        this.esUrgente = esUrgente;
    }

    @Override
    public double calcularCosto() {
        double costoBase = this.getPeso() * 2.5 + this.getDistancia() * 1.3;
        return (this.esUrgente ? costoBase + 7000 : costoBase);
    }

    @Override
    public String toString() {
        return "[Express] " + super.toString() + " | Urgente: " + (esUrgente ? "Sí" : "No");
    }
}
