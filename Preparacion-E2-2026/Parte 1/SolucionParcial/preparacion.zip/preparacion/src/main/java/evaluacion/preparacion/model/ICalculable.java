package evaluacion.preparacion.model;

public interface ICalculable {
    double calcularCosto();
}
