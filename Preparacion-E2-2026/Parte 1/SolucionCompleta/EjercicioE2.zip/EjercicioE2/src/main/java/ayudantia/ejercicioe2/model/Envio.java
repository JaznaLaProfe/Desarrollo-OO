package ayudantia.ejercicioe2.model;

public abstract class Envio implements ICalculable {
    private String codigo;
    private double peso;
    private double distancia;

    public Envio(String codigo, double peso, double distancia) {
        this.setCodigo(codigo);
        this.setPeso(peso);
        this.setDistancia(distancia);
    }

    public String getCodigo() { return this.codigo; }
    public double getPeso() { return this.peso; }
    public double getDistancia() { return this.distancia; }

    public void setCodigo(String nuevoCodigo) {
        if (nuevoCodigo != null && nuevoCodigo.length() >= 3) {
            this.codigo = nuevoCodigo;
        } else {
            throw new IllegalArgumentException("El código debe tener al menos 3 caracteres.");
        }
    }

    public void setPeso(double nuevoPeso) {
        if (nuevoPeso > 0) {
            this.peso = nuevoPeso;
        } else {
            throw new IllegalArgumentException("El peso debe ser mayor a 0.");
        }
    }

    public void setDistancia(double nuevaDistancia) {
        if (nuevaDistancia > 0) {
            this.distancia = nuevaDistancia;
        } else {
            throw new IllegalArgumentException("La distancia debe ser mayor a 0.");
        }
    }

    @Override
    public String toString() {
        return "Código: " + this.codigo + " | Peso: " + this.peso + " kg | Distancia: " +
                this.distancia + " km | Costo: $" + this.calcularCosto();
    }
}
