module ayudantia.ejercicioe2 {
    requires javafx.controls;
    requires javafx.fxml;
    opens ayudantia.ejercicioe2.controller to javafx.fxml;
    exports ayudantia.ejercicioe2.controller;

    opens ayudantia.ejercicioe2 to javafx.fxml;
    exports ayudantia.ejercicioe2;
}