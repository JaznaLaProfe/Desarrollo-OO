package ayudantia.ejercicioe2.model;

public class EnvioEstandar extends Envio {
    private int tarifaBase;

    public EnvioEstandar(String codigo, double peso, double distancia, int tarifaBase) {
        super(codigo, peso, distancia);
        this.setTarifaBase(tarifaBase);
    }

    public int getTarifaBase() { return this.tarifaBase; }

    public void setTarifaBase(int nuevaTarifa) {
        if (nuevaTarifa >= 0) {
            this.tarifaBase = nuevaTarifa;
        } else {
            throw new IllegalArgumentException("La tarifa base no puede ser negativa.");
        }
    }

    @Override
    public double calcularCosto() {
        return this.tarifaBase + this.getPeso() * 1.2 + this.getDistancia() * 0.5;
    }

    @Override
    public String toString() {
        return "[Estándar] " + super.toString() + " | Tarifa Base: $" + tarifaBase;
    }
}
