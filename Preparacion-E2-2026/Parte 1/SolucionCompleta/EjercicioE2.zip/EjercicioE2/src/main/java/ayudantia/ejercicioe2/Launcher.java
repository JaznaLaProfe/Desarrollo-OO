package ayudantia.ejercicioe2;

import javafx.application.Application;

public class Launcher {
    public static void main(String[] args) {
        Application.launch(EnvioApplication.class, args);
    }
}
