package ayudantia.ejercicioe2.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import ayudantia.ejercicioe2.model.Envio;
import ayudantia.ejercicioe2.model.EnvioEstandar;
import ayudantia.ejercicioe2.model.EnvioExpress;

public class EnvioController {

    @FXML
    private ListView<Envio> ListViewEmvios;

    @FXML
    private CheckBox checkUrgente;

    @FXML
    private ComboBox<String> comboTipo;

    @FXML
    private TextField txtCodigo;

    @FXML
    private TextField txtDistancia;

    @FXML
    private TextField txtPeso;

    @FXML
    private TextField txtTarifaBase;

    @FXML
    private Label lblTarifaBase;

    @FXML
    private Label lblEsUrgente;

    // Colección observable que guarda los objetos del Modelo
    private final ObservableList<Envio> coleccionEnvios = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        this.comboTipo.getItems().addAll("Estándar", "Express");
        this.comboTipo.getSelectionModel().selectFirst();
        this.ListViewEmvios.setItems(coleccionEnvios);

        // Listener para cargar los datos del objeto seleccionado en el formulario (READ / UPDATE)
        this.ListViewEmvios.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                this.cargarFormularioDesdeObjeto(newVal);
            }
        });

        this.lblEsUrgente.setVisible(false);
        this.checkUrgente.setVisible(false);

        this.txtCodigo.requestFocus();

    }
    private void cargarFormularioDesdeObjeto(Envio envio) {
        this.txtCodigo.setText(envio.getCodigo());
        this.txtPeso.setText(String.valueOf(envio.getPeso()));
        this.txtDistancia.setText(String.valueOf(envio.getDistancia()));

        if (envio instanceof EnvioEstandar estandar) {
            this.comboTipo.setValue("Estándar");
            this.txtTarifaBase.setText(String.valueOf(estandar.getTarifaBase()));
        } else if (envio instanceof EnvioExpress express) {
            this.comboTipo.setValue("Express");
            this.checkUrgente.setSelected(express.getEsUrgente());
        }
        this.handleCambioTipo();
    }
    @FXML
    private void handleCambioTipo() {
        boolean esEstandar = "Estándar".equals(this.comboTipo.getValue());
        /* Setear los controles relacionados con lo estándar*/
        this.lblTarifaBase.setVisible(esEstandar);
        this.txtTarifaBase.setVisible(esEstandar);
        this.txtTarifaBase.setDisable(!esEstandar);
        /* Setear los controles relacionados con lo express */
        this.lblEsUrgente.setVisible(!esEstandar);
        this.checkUrgente.setVisible(!esEstandar);
        this.checkUrgente.setDisable(esEstandar);
    }
    @FXML
    private void handleActualizar(ActionEvent event) {
        Envio seleccionado = this.ListViewEmvios.getSelectionModel().getSelectedItem();
        if (seleccionado == null) {
            this.mostrarAlerta(Alert.AlertType.WARNING, "Atención", "Seleccione un elemento para actualizar.");
            return;
        }

        try {
            seleccionado.setCodigo(txtCodigo.getText());
            seleccionado.setPeso(Double.parseDouble(txtPeso.getText()));
            seleccionado.setDistancia(Double.parseDouble(txtDistancia.getText()));

            if (seleccionado instanceof EnvioEstandar estandar) {
                estandar.setTarifaBase(Integer.parseInt(txtTarifaBase.getText()));
            } else if (seleccionado instanceof EnvioExpress express) {
                express.setEsUrgente(this.checkUrgente.isSelected());
            }

            this.ListViewEmvios.refresh(); // Refrescar la vista de la lista
            this.handleLimpiar(event);
            this.mostrarAlerta(Alert.AlertType.INFORMATION, "Éxito", "Envío actualizado correctamente.");
        } catch (Exception e) {
            this.mostrarAlerta(Alert.AlertType.ERROR, "Error", e.getMessage());
        }
    }

    @FXML
    private void handleCrear(ActionEvent event) {
        try {
            Envio nuevoEnvio = construirEnvioDesdeFormulario();
            this.coleccionEnvios.add(nuevoEnvio);
            this.handleLimpiar(event);
            this.mostrarAlerta(Alert.AlertType.INFORMATION, "Éxito", "Envío agregado correctamente.");
        } catch (Exception e) {
            this.mostrarAlerta(Alert.AlertType.ERROR, "Error de Validación", e.getMessage());
        }
    }

    private Envio construirEnvioDesdeFormulario() {
        String codigo = txtCodigo.getText();
        double peso = Double.parseDouble(txtPeso.getText());
        double distancia = Double.parseDouble(txtDistancia.getText());

        if ("Estándar".equals(comboTipo.getValue())) {
            int tarifaBase = Integer.parseInt(txtTarifaBase.getText());
            return new EnvioEstandar(codigo, peso, distancia, tarifaBase);
        } else {
            boolean esUrgente = this.checkUrgente.isSelected();
            return new EnvioExpress(codigo, peso, distancia, esUrgente);
        }
    }
    /**
     * Mostrar la alerta si ha ocurrido alguna excepción
     * */
    private void mostrarAlerta(Alert.AlertType tipo, String titulo, String mensaje) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    @FXML
    private void handleEliminar(ActionEvent event) {
        Envio seleccionado = this.ListViewEmvios.getSelectionModel().getSelectedItem();
        if (seleccionado != null) {
            this.coleccionEnvios.remove(seleccionado);
            this.handleLimpiar(event);
            this.mostrarAlerta(Alert.AlertType.INFORMATION, "Éxito", "Envío eliminado.");
        } else {
            this.mostrarAlerta(Alert.AlertType.WARNING, "Atención", "Seleccione un elemento a eliminar.");
        }
    }

    @FXML
    private void handleLimpiar(ActionEvent event) {
        this.txtCodigo.clear();
        this.txtPeso.clear();
        this.txtDistancia.clear();
        this.txtTarifaBase.clear();
        this.checkUrgente.setSelected(false);
        this.comboTipo.getSelectionModel().selectFirst();
        this.ListViewEmvios.getSelectionModel().clearSelection();

        this.txtCodigo.requestFocus();
    }

}

