package ayudantia.ejercicioe2.model;

public interface ICalculable {
    double calcularCosto();
}
